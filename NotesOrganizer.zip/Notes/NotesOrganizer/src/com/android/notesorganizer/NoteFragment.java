package com.android.notesorganizer;

import java.util.Date;
import java.util.UUID;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.NavUtils;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.format.DateFormat;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;

public class NoteFragment extends Fragment 
{
	public static final String EXTRA_NOTE_ID = "com.android.notesorganizer.note_id";
	private static final String DIALOG_DATE = "date";
	private static final String DIALOG_IMAGE = "image";
	
	private static final int REQUEST_DATE = 0;
	private static final int REQUEST_PHOTO = 1;
	private static final int REQUEST_CONTACT = 2;
	
	private Note mNote;
	private EditText mTitleField;
	private Button mDateButton;
	private CheckBox mDoneCheckBox;
	private ImageButton mPhotoButton;
	private ImageView mPhotoView;
	private Button mPersonButton;
	
	public void updateDate() 
	{
		mDateButton.setText(mNote.getmDate().toString());
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) 
	{
	switch (item.getItemId()) 
	{
	case android.R.id.home:
		if (NavUtils.getParentActivityName(getActivity()) != null) 
		{
			NavUtils.navigateUpFromSameTask(getActivity());
		}
	return true;
	default:
	return super.onOptionsItemSelected(item);
	}
	}
	
	@Override
	public void onCreate(Bundle savedInstanceState) 
	{
		setHasOptionsMenu(true);
	super.onCreate(savedInstanceState);
	UUID noteId = (UUID)getArguments().getSerializable(EXTRA_NOTE_ID);
	mNote = NoteLib.get(getActivity()).getNote(noteId);
	}
	
	@TargetApi(11)
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup parent, Bundle savedInstanceState) 
	{	
	View v = inflater.inflate(R.layout.fragment_note, parent, false);
	
	if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) 
	{
		if (NavUtils.getParentActivityName(getActivity()) != null) {
		getActivity().getActionBar().setDisplayHomeAsUpEnabled(true);
		}
	}
	
	Button reportButton = (Button)v.findViewById(R.id.note_informationButton);
	reportButton.setOnClickListener(new View.OnClickListener() 
	{
	public void onClick(View v) 
	{
	 Intent i = new Intent(Intent.ACTION_SEND);
	 i.setType("text/plain");
	 i.putExtra(Intent.EXTRA_TEXT, getNoteInformation());
	 i.putExtra(Intent.EXTRA_SUBJECT,
	 getString(R.string.note_information_subject));
	 i = Intent.createChooser(i, getString(R.string.send_information));
	 startActivity(i);
	}
	});
	
	mTitleField = (EditText)v.findViewById(R.id.note_title);
	mTitleField.setText(mNote.getmTitle());
	mTitleField.addTextChangedListener(new TextWatcher() 
	{
		
	public void onTextChanged(CharSequence s, int start, int before, int count) 
	{	
	mNote.setmTitle(s.toString());
	//mCallbacks.onNoteUpdated(mNote);
	getActivity().setTitle(mNote.getmTitle());
	}
	
	public void beforeTextChanged(CharSequence s, int start, int count, int after) 
	{
	
	}
	@Override
	public void afterTextChanged(Editable s) 
	{
		
	}

	});
	mDateButton = (Button)v.findViewById(R.id.note_date);
	updateDate();
	mDateButton.setOnClickListener(new View.OnClickListener() 
	{
		
		public void onClick(View v) 
		{
		FragmentManager fm = getActivity().getSupportFragmentManager();
		DatePickerFragment dialog = DatePickerFragment.newInstance(mNote.getmDate());
		dialog.setTargetFragment(NoteFragment.this, REQUEST_DATE);
		dialog.show(fm, DIALOG_DATE);
		}
		
		});
	
	mPhotoView = (ImageView)v.findViewById(R.id.note_imageView);
	
	mPhotoView.setOnClickListener(new View.OnClickListener() {
		public void onClick(View v) {
		Photo p = mNote.getPhoto();
		if (p == null)
		return;
		FragmentManager fm = getActivity()
		.getSupportFragmentManager();
		String path = getActivity()
		.getFileStreamPath(p.getFilename()).getAbsolutePath();
		ImageFragment.newInstance(path)
		.show(fm, DIALOG_IMAGE);
		}
		});
	
	mDoneCheckBox = (CheckBox)v.findViewById(R.id.note_done);
	mDoneCheckBox.setChecked(mNote.ismDone());
	mDoneCheckBox.setOnCheckedChangeListener(new OnCheckedChangeListener() 
	{
		
	public void onCheckedChanged(CompoundButton buttonView, boolean isChecked)
	{
	// ���������� ����� ���������� ����
	mNote.setmDone(isChecked);
	//mCallbacks.onNoteUpdated(mNote);
	}
	
	});
	
	mPhotoButton = (ImageButton)v.findViewById(R.id.note_imageButton);
	mPhotoButton.setOnClickListener(new View.OnClickListener() 
	{
		@Override
		public void onClick(View v) 
		{
		Intent i = new Intent(getActivity(), NoteCameraActivity.class);
		startActivityForResult(i, REQUEST_PHOTO);
		}
		});
	
	// ���� ������ ����������, ������������� ����������������
	// ������ � �������
	PackageManager pm = getActivity().getPackageManager();
	if (!pm.hasSystemFeature(PackageManager.FEATURE_CAMERA) &&
	!pm.hasSystemFeature(PackageManager.FEATURE_CAMERA_FRONT)) 
	{
	mPhotoButton.setEnabled(false);
	}
	
	mPersonButton = (Button)v.findViewById(R.id.note_personButton);
	mPersonButton.setOnClickListener(new View.OnClickListener() 
	{
	public void onClick(View v) 
	{
	Intent i = new Intent(Intent.ACTION_PICK,
	ContactsContract.Contacts.CONTENT_URI);
	startActivityForResult(i, REQUEST_CONTACT);
	}
	});
	if (mNote.getPerson() != null) 
	{
	mPersonButton.setText(mNote.getPerson());
	}
	return v;
	}
	
	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) 
	{
	if (resultCode != Activity.RESULT_OK) return;
	if (requestCode == REQUEST_DATE) 
	{
	Date date = (Date)data
	.getSerializableExtra(DatePickerFragment.EXTRA_DATE);
	mNote.setmDate(date);
	//mCallbacks.onNoteUpdated(mNote);
	updateDate();
	} else if (requestCode == REQUEST_PHOTO) 
	{
		// �������� ������ ������� Photo � ���������� ��� � Note
		String filename = data
		.getStringExtra(NoteCameraFragment.EXTRA_PHOTO_FILENAME);
		if (filename != null) 
		{
			Photo p = new Photo(filename);
			mNote.setPhoto(p);
			//mCallbacks.onNoteUpdated(mNote);
			showPhoto();
		}
		
	} else if (requestCode == REQUEST_CONTACT) 
	   {
		Uri contactUri = data.getData();
		// ����������� �����, �������� ������� ������ ����
		// ���������� ��������.
		String[] queryFields = new String[] 
		{
		   ContactsContract.Contacts.DISPLAY_NAME
		};
		// ���������� ������� - contactUri ����� ��������� �������
		// ������� "where"
		Cursor c = getActivity().getContentResolver()
		.query(contactUri, queryFields, null, null, null);
		// �������� ��������� �����������
		if (c.getCount() == 0) 
		{
		 c.close();
		 return;
		}
		// ���������� ������ - ����� ����������� ��������.
		c.moveToFirst();
		String person = c.getString(0);
		mNote.setPerson(person);
		//mCallbacks.onNoteUpdated(mNote);
		mPersonButton.setText(person);
		c.close();
		}
	}
	
	
	public static NoteFragment newInstance(UUID noteId) 
	{
		Bundle args = new Bundle();
		args.putSerializable(EXTRA_NOTE_ID, noteId);
		NoteFragment fragment = new NoteFragment();
		fragment.setArguments(args);
		return fragment;
	}
	
	private void showPhoto() 
	{
		// ���������� �����������, ����������� �� ������ ����������
		Photo p = mNote.getPhoto();
		BitmapDrawable b = null;
		if (p != null) 
		{
		  String path = getActivity()
		  .getFileStreamPath(p.getFilename()).getAbsolutePath();
		  b = PictureUtils.getScaledDrawable(getActivity(), path);
		}
		mPhotoView.setImageDrawable(b);
	}
	
	@Override
	public void onStart() 
	{
	 super.onStart();
	 showPhoto();
	}
	
	@Override
	public void onPause() 
	{
	  super.onPause();
	  NoteLib.get(getActivity()).saveNotes();
	}
	
	@Override
	public void onStop() 
	{
	 super.onStop();
	 PictureUtils.cleanImageView(mPhotoView);
	}
	
	private String getNoteInformation() 
	{
		String doneString = null;
		if (mNote.ismDone()) 
		{
		doneString = getString(R.string.note_information_done);
		} 
		else 
		{
		doneString = getString(R.string.note_information_notdone);
		}
		String dateFormat = "EEE, MMM dd";
		String dateString = DateFormat.format(dateFormat, mNote.getmDate()).toString();
		String person = mNote.getPerson();
		if (person == null) 
		{
		person = getString(R.string.note_information_no_person);
		} 
		else 
		{
		person = getString(R.string.note_information_person, person);
		}
		String information = getString(R.string.note_information,
		mNote.getmTitle(), dateString, doneString, person);
		return information;
		}
	
}
