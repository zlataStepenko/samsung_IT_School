package com.android.notesorganizer;

import java.util.ArrayList;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.ListFragment;
import android.view.ActionMode;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView.MultiChoiceModeListener;
import android.widget.AdapterView.AdapterContextMenuInfo;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.ListView;
import android.widget.TextView;

public class NoteListFragment extends ListFragment 
{
	private ArrayList<Note> mNotes;
	private boolean mSubtitleVisible;

	
	public interface Callbacks 
	{
	   void onNoteSelected(Note note);
	}

	
	@Override
	public void onCreateContextMenu(ContextMenu menu, View v, ContextMenuInfo menuInfo)
	{
	getActivity().getMenuInflater().inflate(R.menu.note_list_item_context, menu);
	}
	
	@Override
	public boolean onContextItemSelected(MenuItem item) 
	{
	AdapterContextMenuInfo info = (AdapterContextMenuInfo)item.getMenuInfo();
	int position = info.position;
	NoteAdapter adapter = (NoteAdapter)getListAdapter();
	Note note = adapter.getItem(position);
	switch (item.getItemId()) 
	{
	case R.id.menu_item_delete_note:
	NoteLib.get(getActivity()).deleteNote(note);
	adapter.notifyDataSetChanged();
	return true;
	}
	return super.onContextItemSelected(item);
	}
	
	@TargetApi(11)
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup parent, Bundle savedInstanceState) 
	{
	 View v = super.onCreateView(inflater, parent, savedInstanceState);
	 if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) 
	 {
	   if (mSubtitleVisible) 
	   {
		 getActivity().getActionBar().setSubtitle(R.string.subtitle);
	   }
	 }
	   ListView listView = (ListView)v.findViewById(android.R.id.list);
	   if (Build.VERSION.SDK_INT < Build.VERSION_CODES.HONEYCOMB) 
	   {
		// ����������� ���� ��� Froyo � Gingerbread
		registerForContextMenu(listView);
		} else 
		{
		// ����������� ������ �������� ��� Honeycomb � ����
		listView.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE_MODAL);
		listView.setMultiChoiceModeListener(new MultiChoiceModeListener() 
		{
			public void onItemCheckedStateChanged(ActionMode mode, int position,
			long id, boolean checked) 
			{
			// ����� �������� ������������, �� �� ������������
			}
			// ������ ActionMode.Callback
			public boolean onCreateActionMode(ActionMode mode, Menu menu) 
			{
			  MenuInflater inflater = mode.getMenuInflater();
			  inflater.inflate(R.menu.note_list_item_context, menu);
			return true;
			}
			public boolean onPrepareActionMode(ActionMode mode, Menu menu) 
			{
			return false;
			// ����� �������� ������������, �� �� ������������
			}
			public boolean onActionItemClicked(ActionMode mode, MenuItem item) 
			{
			 switch (item.getItemId()) 
			 {
			  case R.id.menu_item_delete_note:
			   NoteAdapter adapter = (NoteAdapter)getListAdapter();
			   NoteLib noteLib = NoteLib.get(getActivity());
			  for (int i = adapter.getCount() - 1; i >= 0; i--) 
			  {
				if (getListView().isItemChecked(i)) 
				{
					noteLib.deleteNote(adapter.getItem(i));
				}
			}
					mode.finish();
					adapter.notifyDataSetChanged();
					return true;
					default:
					return false;
			}
			}
					public void onDestroyActionMode(ActionMode mode) {
					// ����� �������� ������������, �� �� ������������		
			}
		});
		}
	 
	   return v;
	}
			
	@Override
	public void onListItemClick(ListView l, View v, int position, long id) 
	{
	  Note c = ((NoteAdapter)getListAdapter()).getItem(position);
	  Intent i = new Intent(getActivity(), NotePagerActivity.class);
	  i.putExtra(NoteFragment.EXTRA_NOTE_ID, c.getmId());
	  startActivity(i);

	}
	
	private class NoteAdapter extends ArrayAdapter<Note> 
	{
		public NoteAdapter(ArrayList<Note> notes) 
		{
		super(getActivity(), 0, notes);
		}
		
	@Override
	public View getView(int position, View convertView, ViewGroup parent) 
	  {
	   // ���� �� �� �������� �������������, ��������� ���
		if (convertView == null) 
		{
		 convertView = getActivity().getLayoutInflater().inflate(R.layout.list_item_note, null);
		}
		// ��������� ������������� ��� ������� Note
		Note c = getItem(position);
		TextView titleTextView = (TextView)convertView.findViewById(R.id.note_list_item_titleTextView);
		titleTextView.setText(c.getmTitle());
		TextView dateTextView = (TextView)convertView.findViewById(R.id.note_list_item_dateTextView);
		dateTextView.setText(c.getmDate().toString());
		CheckBox doneCheckBox = (CheckBox)convertView.findViewById(R.id.note_list_item_doneCheckBox);
		doneCheckBox.setChecked(c.ismDone());
		return convertView;
	 }
  }

	@Override
	public void onCreate(Bundle savedInstanceState) 
	{
	  super.onCreate(savedInstanceState);
	  setHasOptionsMenu(true);
	  getActivity().setTitle(R.string.notes_title);
	  mNotes = NoteLib.get(getActivity()).getNotes();
	  setRetainInstance(true);
	  mSubtitleVisible = false;
	  NoteAdapter adapter = new NoteAdapter(mNotes);
	  setListAdapter(adapter);
	 }
	
	@Override
	public void onResume() 
	{
	 super.onResume();
     ((NoteAdapter)getListAdapter()).notifyDataSetChanged();
	}
	
	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) 
	{
	 ((NoteAdapter)getListAdapter()).notifyDataSetChanged();
	}
	
	@Override
	public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) 
	{
	 super.onCreateOptionsMenu(menu, inflater);
	 inflater.inflate(R.menu.fragment_note_list, menu);
	 MenuItem showSubtitle = menu.findItem(R.id.menu_item_show_subtitle);
	 if (mSubtitleVisible && showSubtitle != null) 
	 {
	  showSubtitle.setTitle(R.string.hide_subtitle);
	 }
	}
	
	@TargetApi(11)
	@Override
	public boolean onOptionsItemSelected(MenuItem item) 
	{
	 switch (item.getItemId()) 
	 {
	    case R.id.menu_item_new_note:
		Note note = new Note();
		NoteLib.get(getActivity()).addNote(note);
		Intent i = new Intent(getActivity(), NotePagerActivity.class);
		i.putExtra(NoteFragment.EXTRA_NOTE_ID, note.getmId());
		startActivity(i);
		return true;
		
	    case R.id.menu_item_show_subtitle:
	    if (getActivity().getActionBar().getSubtitle() == null) 
	    {
		getActivity().getActionBar().setSubtitle(R.string.subtitle);
		mSubtitleVisible = true;
		item.setTitle(R.string.hide_subtitle);
	    } else 
	    {
	    	getActivity().getActionBar().setSubtitle(null);
	    	mSubtitleVisible = false;
	    	item.setTitle(R.string.show_subtitle);
	    }
		return true;
		
		default:
		return super.onOptionsItemSelected(item);
		}
	 
	 
	}
	
}
