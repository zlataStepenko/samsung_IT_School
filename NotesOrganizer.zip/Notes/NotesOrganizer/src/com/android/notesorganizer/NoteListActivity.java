package com.android.notesorganizer;

import android.content.Intent;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;

public class NoteListActivity extends SingleFragmentActivity

{

	@Override
	protected Fragment createFragment() 
	{
		return new NoteListFragment();
	}
	
	@Override
	protected int getLayoutResId() 
	{
		return R.layout.activity_fragment;
	}

	
	public void onNoteUpdated(Note note) 
	{
		
	}
}
