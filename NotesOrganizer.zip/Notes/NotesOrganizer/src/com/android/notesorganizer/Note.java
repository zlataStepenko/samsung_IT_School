package com.android.notesorganizer;

import java.util.Date;
import java.util.UUID;

import org.json.JSONException;
import org.json.JSONObject;

public class Note 
{
	private UUID mId;
	private String mTitle;
	private Date mDate;
	private Photo mPhoto;
	private String mPerson;
	
	private boolean mDone;
	
	private static final String JSON_ID = "id";
	private static final String JSON_TITLE = "title";
	private static final String JSON_DONE = "done";
	private static final String JSON_DATE = "date";
	private static final String JSON_PHOTO = "photo";
	private static final String JSON_PERSON = "person";
	
	public Note() 
	{
	// ������������� ����������� ��������������
	mId = UUID.randomUUID();
	mDate = new Date();
	}
	
	public Note(JSONObject json) throws JSONException 
	{
		mId = UUID.fromString(json.getString(JSON_ID));
		mTitle = json.getString(JSON_TITLE);
		mDone = json.getBoolean(JSON_DONE);
		mDate = new Date(json.getLong(JSON_DATE));
		if (json.has(JSON_PHOTO))
			mPhoto = new Photo(json.getJSONObject(JSON_PHOTO));
		if (json.has(JSON_PERSON))
			mPerson = json.getString(JSON_PERSON);
	}
	
	public JSONObject toJSON() throws JSONException 
	{
		JSONObject json = new JSONObject();
		json.put(JSON_ID, mId.toString());
		json.put(JSON_TITLE, mTitle);
		json.put(JSON_DONE, mDone);
		json.put(JSON_DATE, mDate.getTime());
		if (mPhoto != null)
			json.put(JSON_PHOTO, mPhoto.toJSON());
		    json.put(JSON_PERSON, mPerson);
		return json;
	}
	
	@Override
	public String toString() 
	{
	return mTitle;
	}
	
	public Date getmDate() 
	{
		return mDate;
	}
	
	public void setmDate(Date mDate) 
	{
		this.mDate = mDate;
	}
	
	public boolean ismDone() 
	{
		return mDone;
	}
	
	public void setmDone(boolean mDone) 
	{
		this.mDone = mDone;
	}
	
	public String getmTitle() 
	{
		return mTitle;
	}
	
	public void setmTitle(String mTitle) 
	{
		this.mTitle = mTitle;
	}
	
	public UUID getmId() 
	{
		return mId;
	}
	
	public Photo getPhoto() 
	{
		return mPhoto;
	}
	
	public void setPhoto(Photo p)
	{
		 mPhoto = p;
	}
	
	public String getPerson() 
	{
		return mPerson;
	}
		
	public void setPerson(String person) 
	{
		mPerson = person;
	}
}
