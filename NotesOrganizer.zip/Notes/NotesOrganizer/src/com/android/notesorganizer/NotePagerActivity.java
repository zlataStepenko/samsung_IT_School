package com.android.notesorganizer;

import java.util.ArrayList;
import java.util.UUID;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.ViewPager;

public class NotePagerActivity extends FragmentActivity 
{
	private ViewPager mViewPager;
	private ArrayList<Note> mNotes;
	
	
	@Override
	public void onCreate(Bundle savedInstanceState) 
	{
	super.onCreate(savedInstanceState);
	mViewPager = new ViewPager(this);
	mViewPager.setId(R.id.viewPager);
	setContentView(mViewPager);
	mNotes = NoteLib.get(this).getNotes();
	FragmentManager fm = getSupportFragmentManager();
	mViewPager.setAdapter(new FragmentStatePagerAdapter(fm) 
	{
		
	@Override
	public int getCount() 
	{
	return mNotes.size();
	}
	
	@Override
	public Fragment getItem(int pos) 
	{
	Note note = mNotes.get(pos);
	return NoteFragment.newInstance(note.getmId());
	}
	
	});
	
	mViewPager.setOnPageChangeListener(new ViewPager.OnPageChangeListener() 
	{
		public void onPageScrollStateChanged(int state)
		{
			
		}
		public void onPageScrolled(int pos, float posOffset, int posOffsetPixels) 
		{
			
		}
		public void onPageSelected(int pos) 
		{
		Note note = mNotes.get(pos);
		if (note.getmTitle() != null) 
		{
		setTitle(note.getmTitle());
		}
		
      }
		
		});
	
	UUID noteId = (UUID)getIntent().getSerializableExtra(NoteFragment.EXTRA_NOTE_ID);
			for (int i = 0; i < mNotes.size(); i++) 
			{
			if (mNotes.get(i).getmId().equals(noteId)) 
			{
			mViewPager.setCurrentItem(i);
			break;
			}
			}
	
	}
}
