package com.android.notesorganizer;

import java.util.ArrayList;
import java.util.UUID;

import android.content.Context;
import android.util.Log;

public class NoteLib 
{
	private static final String TAG = "NoteLib";
	private static final String FILENAME = "notes.json";
	private ArrayList<Note> mNotes;
	private static NoteLib sNoteLib;
	private Context mAppContext;
	private NoteJSONSerializer mSerializer;
	public NoteLib(Context appContext)
	{
	  mAppContext = appContext;
	  mSerializer = new NoteJSONSerializer(mAppContext, FILENAME);

	  try 
	  {
		  mNotes = mSerializer.loadNotes();
		 
	   } catch (Exception e) 
	   {
		  mNotes = new ArrayList<Note>();
		  Log.e(TAG, "�� ������� ��������� �������: ", e);
	   }
	}
	
	public static NoteLib get(Context c) 
	{
	 if (sNoteLib == null) 
	 {
	  sNoteLib = new NoteLib(c.getApplicationContext());
	 }
	 return sNoteLib;
    }

	public ArrayList<Note> getNotes() 
	{
		return getmNotes();
	}
	
	public Note getNote(UUID id) 
	{
	  for (Note c : getmNotes()) 
	  {
		if (c.getmId().equals(id))
		return c;
	  }
	  return null;
	  }

	public ArrayList<Note> getmNotes() 
	{
	  return mNotes;
	}

	public void setmNotes(ArrayList<Note> mNotes) 
	{
		this.mNotes = mNotes;
	}
		
	public void addNote(Note c) 
	{
		mNotes.add(c);
	}
	
	public boolean saveNotes() 
	{
	  try 
	  {
		mSerializer.saveNotes(mNotes);
		Log.d(TAG, "������� ���� ��������� � ����.");
		return true;
	  } catch (Exception e) 
	  {
		Log.e(TAG, "�� ������� ��������� ������� � ����: ", e);
		return false;
	  }
	}
	
	public void deleteNote(Note c) 
	{
		mNotes.remove(c);
	}
}
